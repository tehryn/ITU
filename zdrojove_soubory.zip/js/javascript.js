$(function(){
  $('#keywords').tablesorter();
});