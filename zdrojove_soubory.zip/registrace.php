<?php include 'includes/db.php' ?>

<!DOCTYPE html>
<html>
	<head>
		<?php include 'includes/head.php' ?>
		<title>Sunny Night</title>
	</head>
	<body>
		<div id="main-body">
			<?php include 'includes/header.php' ?>
			<div id="wrapper">
				<?php include 'includes/registration.php' ?>
			</div>
		</div>
	</div>
</body>
</html>